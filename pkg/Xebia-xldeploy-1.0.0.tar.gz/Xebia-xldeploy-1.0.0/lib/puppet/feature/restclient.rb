Puppet.features.add(:restclient, :libs => ['xmlsimple', 'rest_client', 'mime-types']) do
  require 'rubygems'
  require 'xmlsimple'
  require 'rest_client'
end