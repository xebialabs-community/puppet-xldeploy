require 'pathname'

Puppet::Type.newtype(:xldeploy_license_install) do

  desc 'Download an XL Deploy license file from the XebiaLabs download site'

  autorequire(:xldeploy_netinstall) do
    requires = []
    catalog.resources.each {|d|
      if (d.class.to_s == "Puppet::Type::Xldeploy_netinstall")
        requires << d.name
      end
    }
    requires
  end

  ensurable do
    desc "xldeploy_license_install resource state"

    defaultto(:present)

    newvalue(:present) do
      provider.create
    end

    newvalue(:absent) do
      provider.destroy
    end
  end

  newparam(:url, :namevar => true) do
    desc 'the url of the required archive'
  end

  newparam(:destinationdirectory) do
    desc 'destination of the extraction operation'
    validate do |value|

      fail('invalid pathname') unless Pathname.new(value).absolute?
    end
  end

  newparam(:proxy_url) do
    desc 'http proxy url'
  end

  newparam(:user) do
    desc 'download user'
  end

  newparam(:password) do
    desc 'download password'
  end

  newproperty(:owner) do
    desc 'the owner setting of the destination'
    defaultto 'xldeploy'
  end

  newproperty(:group) do
    desc 'the group setting of the destination'
    defaultto 'xldeploy'
  end

end